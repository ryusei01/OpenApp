# GalaxyだけでAPKを生成する方法（GitHub Actions）

必要: GitHubアカウント、スマホのブラウザ。

1. GitHubで新しいリポジトリ（例 `pia-direct-bridge`）を作成する。Privateでもよい。
2. この回答で配布する `pia-direct-bridge-source.zip` をスマホに保存する。
3. リポジトリの `Add file` → `Upload files` でZIPを**解凍せず**そのままアップロードし、`Commit changes`。
4. `Add file` → `Create new file` でファイル名を `.github/workflows/build-from-zip.yml` にする。
5. この回答で配布する `build-from-zip.yml` の中身を貼り付けて `Commit changes`。
6. `Actions` タブ → `Build Pia APK from uploaded ZIP` → 成功した実行 → `Artifacts` → `pia-direct-bridge-apk` をダウンロード。
7. ダウンロードしたArtifacts ZIPを解凍すると `app-debug.apk` がある。それをタップしてインストールする。

※ GitHubの画面がモバイル表示で操作しづらい場合、Chromeの「PC版サイト」をONにする。
※ GitHub Actions自体はGitHubのサーバー上でビルドするのでPC不要。
※ 生成されるのはdebug用APK。実機でのぴあアプリへの遷移成功は未検証。

参考: https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository
参考: https://docs.github.com/ja/actions/how-tos/manage-workflow-runs/download-workflow-artifacts
