package dev.pialink.bridge;

import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Validates the actual URL; never rewrites eventCd / rlsCd / lotRlsCd. */
public final class PiaUrl {
    private static final Pattern PIA_LINK = Pattern.compile("https://t\\.pia\\.jp/[^\\s<>\\\"']+", Pattern.CASE_INSENSITIVE);
    private PiaUrl() { }

    public static String extract(String text) {
        if (text == null) return "";
        Matcher matcher = PIA_LINK.matcher(text.trim());
        if (matcher.find()) return trimTerminalPunctuation(matcher.group());
        // Accept a Google Search redirect sharing URL, without network access.
        try {
            URI outer = URI.create(text.trim());
            if ("www.google.com".equalsIgnoreCase(outer.getHost()) && "/url".equals(outer.getPath())) {
                String redirect = getParam(outer.getRawQuery(), "url");
                if (redirect != null) return extract(redirect);
            }
        } catch (IllegalArgumentException ignored) { }
        return text.trim();
    }

    private static String trimTerminalPunctuation(String s) {
        while (s.endsWith(".") || s.endsWith(",") || s.endsWith(")") || s.endsWith("。") || s.endsWith("、")) {
            s = s.substring(0, s.length() - 1);
        }
        return s;
    }

    public static boolean isPiaHttpsUrl(String input) {
        try {
            URI u = URI.create(input.trim());
            return "https".equalsIgnoreCase(u.getScheme())
                && "t.pia.jp".equalsIgnoreCase(u.getHost())
                && u.getRawUserInfo() == null
                && (u.getPort() == -1 || u.getPort() == 443)
                && u.getRawFragment() == null;
        } catch (RuntimeException e) {
            return false;
        }
    }

    public static boolean isTicketInformation(String input) {
        try {
            return isPiaHttpsUrl(input) && "/pia/ticketInformation.do".equals(URI.create(input.trim()).getPath());
        } catch (RuntimeException e) {
            return false;
        }
    }

    public static String getParam(String query, String key) {
        if (query == null || key == null) return null;
        for (String item : query.split("&", -1)) {
            String[] pair = item.split("=", 2);
            if (decode(pair[0]).equals(key)) return pair.length == 2 ? decode(pair[1]) : "";
        }
        return null;
    }

    private static String decode(String s) {
        try {
            return URLDecoder.decode(s, StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            return s;
        }
    }

    public static String describe(String input) {
        if (!isPiaHttpsUrl(input)) return "t.pia.jp の HTTPS URL を入力してください。";
        URI u = URI.create(input.trim());
        String event = getParam(u.getRawQuery(), "eventCd");
        String sale = getParam(u.getRawQuery(), "rlsCd");
        String lottery = getParam(u.getRawQuery(), "lotRlsCd");
        String path = u.getPath();
        return "URLパス: " + path + "\n"
            + "eventCd: " + label(event) + "\n"
            + "rlsCd: " + label(sale) + "\n"
            + "lotRlsCd: " + label(lottery) + "\n"
            + "元URLを変更せずに送信します。";
    }

    private static String label(String s) {
        return s == null ? "(なし)" : s.isEmpty() ? "(空欄)" : s;
    }
}
