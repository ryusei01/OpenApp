package dev.pialink.bridge;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Directly asks Android to launch the official Ticket Pia app with the ORIGINAL URL.
 * It cannot bypass the target app's own exported intent-filter declarations.
 */
public final class MainActivity extends Activity {
    private static final String PIA_PACKAGE = "jp.co.pia.ticketpia";
    private static final String DEFAULT_URL =
        "https://t.pia.jp/pia/ticketInformation.do?eventCd=2624160&rlsCd=013&lotRlsCd=";

    private EditText urlInput;
    private TextView info;
    private TextView status;
    private CheckBox autoForward;
    private String diagnosticLog = "";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createUi();
        String stored = getPreferences(MODE_PRIVATE).getString("last_url", DEFAULT_URL);
        String original = savedInstanceState == null ? stored : savedInstanceState.getString("url", stored);
        urlInput.setText(original);
        autoForward.setChecked(getPreferences(MODE_PRIVATE).getBoolean("auto_forward", true));
        showUrlSummary();
        acceptIncoming(getIntent());
    }

    @Override public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        acceptIncoming(intent);
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        state.putString("url", urlInput.getText().toString());
        super.onSaveInstanceState(state);
    }

    private void createUi() {
        int pad = dp(16);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, dp(20), pad, dp(28));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("ぴあ直接起動");
        title.setTextSize(23);
        title.setPadding(0, 0, 0, dp(10));
        root.addView(title);

        TextView explanation = new TextView(this);
        explanation.setText("Chromeを経由せず、元のURLをチケットぴあアプリに指定して渡します。rlsCdなどは削除しません。");
        explanation.setTextSize(14);
        root.addView(explanation);

        urlInput = new EditText(this);
        urlInput.setHint("https://t.pia.jp/pia/ticketInformation.do?eventCd=...&rlsCd=...");
        urlInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        urlInput.setSingleLine(false);
        urlInput.setMinLines(3);
        urlInput.setMaxLines(7);
        urlInput.setTextSize(15);
        root.addView(urlInput);

        addButton(root, "ぴあアプリに直接渡す", this::launchPia);
        addButton(root, "クリップボードのURLを貼り付け", this::pasteClipboard);

        autoForward = new CheckBox(this);
        autoForward.setText("共有で受け取ったらすぐ開く");
        autoForward.setOnCheckedChangeListener((buttonView, value) ->
            getPreferences(MODE_PRIVATE).edit().putBoolean("auto_forward", value).apply());
        root.addView(autoForward);

        info = new TextView(this);
        info.setTextSize(14);
        info.setPadding(0, dp(10), 0, dp(10));
        root.addView(info);

        status = new TextView(this);
        status.setTextSize(14);
        status.setTextIsSelectable(true);
        status.setMovementMethod(new ScrollingMovementMethod());
        root.addView(status);

        addButton(root, "診断結果をコピー", this::copyLog);
        TextView note = new TextView(this);
        note.setText("※ 起動要求に成功しても、ぴあアプリ内で販売枠が表示されたことまでは検証できません。\n"
            + "※ このアプリはChromeへ自動転送しません。\n"
            + "※ Androidの仕様上、URLをタップしただけではChromeが優先されることがあります。その場合はURLの『共有』から本アプリを選択してください。");
        note.setTextSize(12);
        note.setPadding(0, dp(12), 0, 0);
        root.addView(note);
        setContentView(scroll);
        setStatus("準備完了。元URLを貼り付けるか共有してください。");
    }

    private void addButton(LinearLayout root, String label, Runnable action) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setOnClickListener(v -> action.run());
        root.addView(button);
    }

    private void pasteClipboard() {
        ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (manager == null || !manager.hasPrimaryClip()) {
            setStatus("クリップボードが空です。");
            return;
        }
        ClipData data = manager.getPrimaryClip();
        if (data == null || data.getItemCount() == 0) return;
        CharSequence text = data.getItemAt(0).coerceToText(this);
        if (text != null) {
            urlInput.setText(PiaUrl.extract(text.toString()));
            showUrlSummary();
            setStatus("貼り付けました。『ぴあアプリに直接渡す』を押してください。");
        }
    }

    private void acceptIncoming(Intent incoming) {
        if (incoming == null) return;
        String text = null;
        if (Intent.ACTION_VIEW.equals(incoming.getAction()) && incoming.getData() != null) {
            text = incoming.getDataString();
        } else if (Intent.ACTION_SEND.equals(incoming.getAction())) {
            CharSequence extra = incoming.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (extra != null) text = extra.toString();
        }
        if (text == null || text.isEmpty()) return;
        final String extracted = PiaUrl.extract(text);
        urlInput.setText(extracted);
        showUrlSummary();
        setStatus("共有されたURLを受け取りました。");
        if (autoForward.isChecked() && PiaUrl.isPiaHttpsUrl(extracted)) {
            // The UI is ready, and the launch occurs only for a valid t.pia.jp HTTPS link.
            urlInput.post(this::launchPia);
        }
    }

    private void showUrlSummary() {
        String url = urlInput.getText().toString().trim();
        info.setText(PiaUrl.describe(url));
    }

    private void launchPia() {
        final String url = PiaUrl.extract(urlInput.getText().toString());
        if (!PiaUrl.isPiaHttpsUrl(url)) {
            setStatus("拒否: t.pia.jp の正しいHTTPS URLを入力してください。");
            showUrlSummary();
            return;
        }
        urlInput.setText(url);
        getPreferences(MODE_PRIVATE).edit().putString("last_url", url).apply();
        showUrlSummary();

        boolean isInstalled;
        try {
            getPackageManager().getPackageInfo(PIA_PACKAGE, 0);
            isInstalled = true;
        } catch (PackageManager.NameNotFoundException e) {
            isInstalled = false;
        }
        if (!isInstalled) {
            setStatus("チケットぴあ公式アプリが見つかりません (" + PIA_PACKAGE + ")。");
            return;
        }

        Uri uri = Uri.parse(url);
        Intent browsable = new Intent(Intent.ACTION_VIEW, uri);
        browsable.addCategory(Intent.CATEGORY_BROWSABLE);
        browsable.setPackage(PIA_PACKAGE);
        browsable.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(browsable);
            setStatus("起動要求を受け付けました（BROWSABLE）。\n"
                + "送信URL: " + url + "\n"
                + "実際に販売枠へ遷移したかは、ぴあアプリ側で確認してください。");
            return;
        } catch (ActivityNotFoundException | SecurityException e) {
            // Retry with the same URL without the optional BROWSABLE category.
        } catch (RuntimeException e) {
            setStatus("起動に失敗: " + e.getClass().getSimpleName() + "\n" + e.getMessage());
            return;
        }

        Intent basic = new Intent(Intent.ACTION_VIEW, uri);
        basic.setPackage(PIA_PACKAGE);
        basic.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(basic);
            setStatus("起動要求を受け付けました（ACTION_VIEW）。\n"
                + "送信URL: " + url + "\n"
                + "実際に販売枠へ遷移したかは、ぴあアプリ側で確認してください。");
        } catch (ActivityNotFoundException e) {
            setStatus("直接起動不可: チケットぴあにこのURLを処理する公開画面がありません。\n"
                + "確認した方式: ACTION_VIEW + パッケージ指定（BROWSABLE有/無）\n"
                + "送信URL: " + url + "\n"
                + "ブラウザには転送していません。");
        } catch (SecurityException e) {
            setStatus("直接起動拒否: チケットぴあ側が外部アプリからの画面起動を許可していません。\n"
                + "送信URL: " + url);
        } catch (RuntimeException e) {
            setStatus("起動に失敗: " + e.getClass().getSimpleName() + "\n" + e.getMessage());
        }
    }

    private void copyLog() {
        ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (manager != null) {
            String text = diagnosticLog + "\n" + PiaUrl.describe(urlInput.getText().toString());
            manager.setPrimaryClip(ClipData.newPlainText("ぴあ直接起動 診断", text));
            setStatus("診断結果をコピーしました。\n" + diagnosticLog);
        }
    }

    private void setStatus(String message) {
        diagnosticLog = message;
        status.setText("診断結果:\n" + message);
    }

    private int dp(int amount) {
        return (int) (amount * getResources().getDisplayMetrics().density + .5f);
    }
}
