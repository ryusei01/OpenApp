# ぴあ直接起動 (Pia Direct Bridge)

Android 8+ (Android 16 含む) / Java / Android Gradle Plugin 8.7.3

目的: `https://t.pia.jp/pia/ticketInformation.do?eventCd=...&rlsCd=...&lotRlsCd=...` を、URL内の全パラメータを保ったまま、公式チケットぴあアプリ (package `jp.co.pia.ticketpia`) に **直接** 渡す実験アプリです。

## このアプリがすること

- Google Keep / スプレッドシート / Chrome の「共有」からテキストのURLを受信
- `eventCd`、`rlsCd`、`lotRlsCd` を削除・書き換えせずに元URLを送る
- Android `Intent.ACTION_VIEW` + `setPackage("jp.co.pia.ticketpia")` を実行
- 初回は `CATEGORY_BROWSABLE` あり、失敗したら同じURLでなしを試す
- 公開された対応Activityがない場合はエラーを表示し、自動でChromeに戻さない
- URLを共有すると、初期設定では自動起動を試す（オフに変更可）
- 最後のURLと設定を端末内に保存

## 制限（重要）

`setPackage` はAndroidのブラウザ選択を避けてぴあアプリを指定できますが、ぴあアプリ自身が `ticketInformation.do` のURLを処理する公開Activityを提供していなければ起動できません。成功メッセージはAndroidが起動要求を受け入れたことを意味し、目的の販売枠 (`rlsCd`) が表示されたことを証明しません。Androidの非公開Activityを強制起動したり、ぴあアプリ内の任意画面へアクセスしたりはしません。

Android 12以降は、ぴあが公式に検証したドメインをこちらの非公式アプリが自動的に奪うことはできません。そのため **URLをタップするだけで必ず本アプリが開く仕組みではありません**。KeepまたはChromeの「共有」→「ぴあ直接起動」の流れで使えます。

## GitHub Actions でAPKをビルドする（PC不要）

スマートフォンだけで作る場合は、同梱の `BUILD_ON_PHONE.md` を参照してください。

GitHubにこのソースツリーを通常のリポジトリとしてアップロードできるなら `.github/workflows/build-apk.yml` が自動でデバッグAPKをビルドします。

## Android StudioでAPKをビルドする

このフォルダーをプロジェクトとして開き、Gradleで同期し、`app` の `assembleDebug` を実行します。Gradle 8.9 / Java 17 / Android SDK API 35が必要です（プロジェクト内にGradle wrapper JARは含みません）。

APK: `app/build/outputs/apk/debug/app-debug.apk`

これは署名済みdebugビルドで通常の端末にテストインストールできます。Playストア公開用のrelease署名ではありません。

## インストール後

1. アプリを起動。例のURLが入力されている。
2. 「ぴあアプリに直接渡す」をタップ。
3. 起動したら、販売枠が開けたか確認。
4. 失敗したらアプリに戻り「診断結果をコピー」。
5. Keep等からは共有メニューで「ぴあ直接起動」を選択。

## 安全・通信

権限は不要、通信なし、ブラウザの自動起動なし。受信したURLを第三者に送信しません。
