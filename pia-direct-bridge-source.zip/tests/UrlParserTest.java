import dev.pialink.bridge.PiaUrl;

public final class UrlParserTest {
    private static void verify(boolean b, String message) {
        if (!b) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        String source = "https://t.pia.jp/pia/ticketInformation.do?eventCd=2624160&rlsCd=013&lotRlsCd=";
        verify(source.equals(PiaUrl.extract(source)), "should not modify URL");
        verify(source.equals(PiaUrl.extract("Shared: " + source + "\nMore text")), "share text extraction");
        verify(PiaUrl.isPiaHttpsUrl(source), "valid host and https");
        verify(PiaUrl.isTicketInformation(source), "ticket information path");
        verify(PiaUrl.describe(source).contains("rlsCd: 013"), "leading zero kept");
        verify(PiaUrl.describe(source).contains("lotRlsCd: (空欄)"), "empty parameter kept");
        verify(!PiaUrl.isPiaHttpsUrl("https://t.pia.jp.evil.example/pia/ticketInformation.do?eventCd=1"), "reject hostname trick");
        verify(!PiaUrl.isPiaHttpsUrl("http://t.pia.jp/pia/ticketInformation.do"), "reject HTTP");
        verify(!PiaUrl.isPiaHttpsUrl("https://name@t.pia.jp/pia/ticketInformation.do"), "reject username");
        String google = "https://www.google.com/url?url=https%3A%2F%2Ft.pia.jp%2Fpia%2FticketInformation.do%3FeventCd%3D2624160%26rlsCd%3D013%26lotRlsCd%3D";
        verify(source.equals(PiaUrl.extract(google)), "Google redirect extraction");
        System.out.println("All PiaUrl tests passed");
    }
}
